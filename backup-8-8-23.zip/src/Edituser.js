import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

const Edituser = () => {
        // Use the useNavigate hook from react-router-dom to get the navigation function

    let history = useNavigate();

        // Use the useParams hook from react-router-dom to get the 'id' parameter from the URL

    const { id } = useParams();

        // Set the initial state for the user data using the useState hook
        const [showAccessRow, setShowAccessRow] = useState(false);
        const [selectedReport, setSelectedReport] = useState(null);
        const [selectedReports, setSelectedReports] = useState([]);
    const [user, setUser] = useState({
        name: "",
        email: "",
        url: "",
        password: "",
        slug: "",
        iframe: "",
        id: ""
    });

    useEffect(() => {
        loadUsers();
    }, []);

        // Destructure the user state object for easier access to its properties

    const { name, email, url, password, slug, iframe } = user;

        // Handle input change for text fields (name, email, url, password, slug, and iframe)

    const handleChange = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value });
    };
        // Handle checkbox change for GA (Google Analytics) access


  
    // Handle form submission to update the user data

    const updateFrom = async (e) => {
        e.preventDefault();
        console.log(user);
      
        // Convert checkbox values (gaChecked, gscChecked, gmbChecked, gadsChecked) to '1' or '0'
        const userData = {
          ...user,
          reports: selectedReports.map((report) => ({
            report_name: report,
            iframe_link: "", 
            ga: selectedReports.includes(`${report}_ga`) ? "1" : "0",
            gsc: selectedReports.includes(`${report}_gsc`) ? "1" : "0",
            gmb: selectedReports.includes(`${report}_gmb`) ? "1" : "0",
            gads: selectedReports.includes(`${report}_gads`) ? "1" : "0",
          })),
        };
        console.log(userData);
 
    };

        // Load the user data from the backend API 
    const loadUsers = async () => {
        console.log('AA' + id);
        try {
                // Send a GET request to the backend API to get the user data based on the 'id'
            const result = await axios.get('https://react.opositive.io/edit-user.php?id=' + id);
             // Extract the user data from the API response
            const userFromServer = result.data;
               // Set the user state with the fetched user data and convert checkbox values to booleans

            setUser({
                ...userFromServer
            });
        } catch (error) {
            console.error("Error fetching user data:", error);
        }
    };
    const handleAddReportClick = () => {
        setShowAccessRow(!showAccessRow);
        setSelectedReport(null); // Reset the selected report when toggling the access row
      };
    
      const handleReportCheckboxChange = (report) => {
        setSelectedReports((prevSelectedReports) => {
          // If the report is already in the selectedReports array, remove it
          if (prevSelectedReports.includes(report)) {
            return prevSelectedReports.filter((selectedReport) => selectedReport !== report);
          }
          // If the report is not in the selectedReports array, add it
          return [...prevSelectedReports, report];
        });
      };
    return (
        <>
            <div className="container">
                <h1 className="heading">Edit User</h1>
                <p id="success">User Updated Successfully!</p>
                <div className="row edit-user-row">
                <form onSubmit={e => updateFrom(e)}>

<div className="col-lg-12">
<div className="row">
<div className="col-lg-6 col-md-12 register-form-col"> 
<label >Name</label>
<input type="text"  name='user_name' className="form-control" value={name} onChange={e => handleChange(e)}/>
</div>


<div className="col-lg-6 col-md-12 register-form-col"> 
<label>Email</label>
<input type="email"  name='email' required className="form-control" value={email} onChange={e => handleChange(e)}/>
</div>
</div>

<div className="row">
<div className="col-lg-6 col-md-12 register-form-col"> 
<label>Website Url</label>
<input type="url"  name='url' required className="form-control" value={url} onChange={e => handleChange(e)}/>
</div>
<div className="col-lg-6 col-md-12 register-form-col"> 
<label>Iframe</label>
<textarea  name='iframe' required className="form-control" value={iframe} onChange={e => handleChange(e)}/>
</div>
</div>

<div className="row">
<div className="col-lg-6 col-md-12 register-form-col"> 
<label>Slug</label>
<input type="text"  name='slug' required className="form-control" value={slug} onChange={e => handleChange(e)}/>
</div>

<div className="col-lg-6 col-md-12 register-form-col"> 
<label>Password</label>
<input type="password"  name='password' required className="form-control"  autoComplete="on" value={password} onChange={e => handleChange(e)}/>
</div>
</div>
<br />
<div className="col-lg-6 col-md-12 register-form-col">
{showAccessRow && (
<div className="row access-row">
  <p className="select-reports">Select reports</p>
  <div className="col-lg-4 col-sm-12 access-required">
    <label>Revenue Report</label>
    <input
      type="checkbox"
      name="revenue"
      checked={selectedReports.includes("revenue")}
      onChange={() => handleReportCheckboxChange("revenue")}
    />
  </div>

  <div className="col-lg-4 col-sm-12 access-required">
    <label>ADS Report</label>
    <input
      type="checkbox"
      name="ads"
      checked={selectedReports.includes("ads")}
      onChange={() => handleReportCheckboxChange("ads")}
    />
  </div>

  <div className="col-lg-4 col-sm-12 access-required">
    <label>Traffic Report</label>
    <input
      type="checkbox"
      name="traffic"
      checked={selectedReports.includes("traffic")}
      onChange={() => handleReportCheckboxChange("traffic")}
    />
  </div>
</div>
                     )}
</div>
<div className="row reports-row">
{selectedReports.includes("revenue") && (
     <div  className="col-lg-5 col-md-12 col-sm-12 add-new-report-card">
     <h2 className="report-heading">Revenue Report</h2>
        <div className="col-lg-11 col-md-12 report-form-col">
           <label>Iframe Link</label>
             <input type="url"  className="form-control"  />
   </div>
   <div className="col-lg-11 col-md-12 report-form-col">
           <label>Access Granted</label>
           <div className="row access-row">
                   
                   <div className="col-lg-3 col-sm-12 access-required">
                     <label>GA</label>
                     <input
                       type="checkbox"
                       name="ga"
                     />
                   </div>
                
                
                   <div className="col-lg-3 col-sm-12 access-required">
                     <label>GSC</label>
                     <input
                       type="checkbox"
                       name="gsc"
                     />
                   </div>
           
          
                   <div className="col-lg-3 col-sm-12 access-required">
                     <label>GMB</label>
                     <input
                       type="checkbox"
                       name="gmb"
                     />
                   </div>
              
                   <div className="col-lg-3 col-sm-12 access-required">
                     <label>GADS</label>
                     <input
                       type="checkbox"
                       name="gads"
                     />
                   </div>
               </div>
           <div className="row send-reminder-row">
           <button type="button" className="reminder-button">
                  Send Reminder
               </button>
           </div>
   </div>
                            </div>
  )}
{selectedReports.includes("ads") &&  (
 <div  className="col-lg-5 col-md-12 col-sm-12 add-new-report-card">
     <h2 className="report-heading">ADS Report</h2>
        <div className="col-lg-11 col-md-12 report-form-col">
           <label>Iframe Link</label>
             <input type="url"  className="form-control"  />
   </div>
   <div className="col-lg-11 col-md-12 report-form-col">
           <label>Access Granted</label>
           <div className="row access-row">
                   
                   <div className="col-lg-3 col-sm-12 access-required">
                     <label>GA</label>
                     <input
                       type="checkbox"
                       name="ga"
                     />
                   </div>
                
                
                   <div className="col-lg-3 col-sm-12 access-required">
                     <label>GSC</label>
                     <input
                       type="checkbox"
                       name="gsc"
                     />
                   </div>
           
          
                   <div className="col-lg-3 col-sm-12 access-required">
                     <label>GMB</label>
                     <input
                       type="checkbox"
                       name="gmb"
                     />
                   </div>
              
                   <div className="col-lg-3 col-sm-12 access-required">
                     <label>GADS</label>
                     <input
                       type="checkbox"
                       name="gads"
                     />
                   </div>
               </div>
               <div className="row send-reminder-row">
           <button type="button" className="reminder-button">
                  Send Reminder
               </button>
           </div>
   </div>
</div>
 )}
{selectedReports.includes("traffic") &&(
<div  className="col-lg-5 col-md-12 col-sm-12 add-new-report-card">
     <h2 className="report-heading">Traffic Report</h2>
        <div className="col-lg-11 col-md-12 report-form-col">
           <label>Iframe Link</label>
             <input type="url"  className="form-control"  />
   </div>
   <div className="col-lg-11 col-md-12 report-form-col">
           <label>Access Granted</label>
           <div className="row access-row">
                   
                   <div className="col-lg-3 col-sm-12 access-required">
                     <label>GA</label>
                     <input
                       type="checkbox"
                       name="ga"
                     />
                   </div>
                
                
                   <div className="col-lg-3 col-sm-12 access-required">
                     <label>GSC</label>
                     <input
                       type="checkbox"
                       name="gsc"
                     />
                   </div>
           
          
                   <div className="col-lg-3 col-sm-12 access-required">
                     <label>GMB</label>
                     <input
                       type="checkbox"
                       name="gmb"
                     />
                   </div>
              
                   <div className="col-lg-3 col-sm-12 access-required">
                     <label>GADS</label>
                     <input
                       type="checkbox"
                       name="gads"
                     />
                   </div>
               </div>
   </div>
   <div className="row send-reminder-row">
           <button type="button" className="reminder-button">
                  Send Reminder
               </button>
           </div>
</div>
)}
</div>

<button type="button" className="add-report" onClick={handleAddReportClick}>
  {showAccessRow ? "Hide Reports" : "Add Report"}
</button>
    
<div className="col-lg-6 col-md-12 text-left register-button">
<div className="row edit-user-submit">
 <div className="col-lg-4 col-md-12">
 <input type="submit" name = 'submit' value='Update User' className="btn btn-success"/>
 </div>
 <div className="col-lg-4 col-md-12">
 <Link to='/home'>
  <button className="cancel">
    Cancel
   </button>
  </Link>
 </div>
</div>
 
</div>

</div>
</form>
                </div>
            </div>
        </>
    );
};

export default Edituser;