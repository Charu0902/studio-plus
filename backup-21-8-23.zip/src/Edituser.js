import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

const Edituser = () => {
        // Use the useNavigate hook from react-router-dom to get the navigation function

    let history = useNavigate();

        // Use the useParams hook from react-router-dom to get the 'id' parameter from the URL

    const { id } = useParams();

        // Set the initial state for the user data using the useState hook
        const [showAccessRow, setShowAccessRow] = useState(false);
        const [selectedReport, setSelectedReport] = useState(null);
        const [selectedReports, setSelectedReports] = useState([]);
    const [user, setUser] = useState({
        name: "",
        email: "",
        url: "",
        slug: "",
        id: "",
        iframelinktraffic:"",
        iframelinkrevenue:"",
        iframelinkads:"",
        gaCheckedrevenue: false,
    gscCheckedrevenue: false,
    gmbCheckedrevenue:false,
    gadsCheckedrevenue:false,
    gaCheckedads: false,
    gscCheckedads: false,
    gmbCheckedads:false,
    gadsCheckedads:false,
    gaCheckedtraffic: false,
    gscCheckedtraffic: false,
    gmbCheckedtraffic:false,
    gadsCheckedtraffic:false,
    });

    useEffect(() => {
        loadUsers();
    }, []);
    

        // Destructure the user state object for easier access to its properties

    const { name, email, url, slug, iframelinktraffic, iframelinkrevenue, iframelinkads,gaCheckedrevenue, gscCheckedrevenue, gmbCheckedrevenue, gadsCheckedrevenue, gaCheckedads,gscCheckedads,gmbCheckedads,gadsCheckedads, gaCheckedtraffic,gscCheckedtraffic,gmbCheckedtraffic,gadsCheckedtraffic} = user;

        // Handle input change for text fields (name, email, url, password, slug, and iframe)

    const handleChange = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value });
    };
    const handleGaChangerevenue = (e) => {
      setUser({ ...user, gaCheckedrevenue: e.target.checked });
    };
  
    // Handle change event for GSC checkbox and update state accordingly
    const handleGscChangerevenue = (e) => {
      setUser({ ...user, gscCheckedrevenue: e.target.checked });
    };
  
      // Handle change event for GMB checkbox and update state accordingly
      const handleGmbChangerevenue = (e) => {
        setUser({ ...user, gmbCheckedrevenue: e.target.checked });
      };
  
        // Handle change event for Google Ads checkbox and update state accordingly
      const handleGadsChangerevenue = (e) => {
        setUser({ ...user, gadsCheckedrevenue: e.target.checked });
      };

      const handleGaChangeads = (e) => {
        setUser({ ...user, gaCheckedads: e.target.checked });
      };
    
      // Handle change event for GSC checkbox and update state accordingly
      const handleGscChangeads = (e) => {
        setUser({ ...user, gscCheckedads: e.target.checked });
      };
    
        // Handle change event for GMB checkbox and update state accordingly
        const handleGmbChangeads = (e) => {
          setUser({ ...user, gmbCheckedads: e.target.checked });
        };
    
          // Handle change event for Google Ads checkbox and update state accordingly
        const handleGadsChangeads = (e) => {
          setUser({ ...user, gadsCheckedads: e.target.checked });
        };

        const handleGaChangetraffic = (e) => {
          setUser({ ...user, gaCheckedtraffic: e.target.checked });
        };
      
        // Handle change event for GSC checkbox and update state accordingly
        const handleGscChangetraffic = (e) => {
          setUser({ ...user, gscCheckedtraffic: e.target.checked });
        };
      
          // Handle change event for GMB checkbox and update state accordingly
          const handleGmbChangetraffic = (e) => {
            setUser({ ...user, gmbCheckedtraffic: e.target.checked });
          };
      
            // Handle change event for Google Ads checkbox and update state accordingly
          const handleGadsChangetraffic = (e) => {
            setUser({ ...user, gadsCheckedtraffic: e.target.checked });
          };
        
      // Assuming this function is called when the "Send Reminder" button is clicked
const sendReminder = (event,report) =>{
  const { email } = user;
  const uncheckedReports = [];

  // Collect the names of unchecked reports
  const reportname = document.querySelector(`.report-heading.${report}`).innerHTML;


  const reportCheckboxes = document.querySelectorAll(`.access-required.checkbox.${report} input[type="checkbox"]`);
  reportCheckboxes.forEach(checkbox => {
      if (!checkbox.checked) {
          uncheckedReports.push(checkbox.name);
      }
  });
console.log(uncheckedReports)
console.log(email)
console.log(reportname)
if (event) {
  event.preventDefault();
}
axios.post("https://react.opositive.io/PHPMailer-master/studio-plus/send_reminder.php", { uncheckedReports,email,reportname })
// .then(response => response.json())
.then((response) => {
  console.log('Email sent');
  const reminderElement = document.querySelector(`.reminder.${report}`);
if (reminderElement) {
  reminderElement.style.display = 'block';
}

   setTimeout(myGreeting, 3000);

function myGreeting() {
  window.location.reload(false);
}
  
})
.catch((error) => {
  console.log('Error sending email:', error);
  // Redirect to the thank you page or any other page you like
});
event.preventDefault();
}

    // Handle form submission to update the user data

    const updateFrom = async (e) => {
        e.preventDefault();
        console.log(user);
      
        // Convert checkbox values  to '1' or '0'
        const userData = {
          ...user,
          reports: selectedReports.map((report) => ({
            report_name: report,
            iframe_link: user[`iframelink${report}`] || "", 
            ga: user[`gaChecked${report}`] ? '1' : '0',
      gsc: user[`gscChecked${report}`] ? '1' : '0',
      gmb: user[`gmbChecked${report}`] ? '1' : '0',
      gads: user[`gadsChecked${report}`] ? '1' : '0'
          })),
        };
        console.log(userData);
 
    };

        // Load the user data from the backend API 
    const loadUsers = async () => {
        console.log('AA' + id);
        try {
                // Send a GET request to the backend API to get the user data based on the 'id'
            const result = await axios.get('https://react.opositive.io/edit-user.php?id=' + id);
             // Extract the user data from the API response
            const userFromServer = result.data;
               // Set the user state with the fetched user data and convert checkbox values to booleans

            setUser({
                ...userFromServer
            });
        } catch (error) {
            console.error("Error fetching user data:", error);
        }
    };
    const handleAddReportClick = () => {
        setShowAccessRow(!showAccessRow);
        setSelectedReport(null); // Reset the selected report when toggling the access row
        var addperport = document.getElementById('add-report-buuton');
        addperport.style.display = 'none'
      };
    
      const handleReportCheckboxChange = (report) => {
        setSelectedReports((prevSelectedReports) => {
          // If the report is already in the selectedReports array, remove it
          if (prevSelectedReports.includes(report)) {
            return prevSelectedReports.filter((selectedReport) => selectedReport !== report);
          }
          // If the report is not in the selectedReports array, add it
          return [...prevSelectedReports, report];
        });
      };

     // Define a function called areAllAccessChecked that takes a 'report' parameter.

     //only for revenue report
     const areAllAccessCheckedrevenue = () => {
      // List of access keys that need to be checked for the revenue report
      const accessKeys = ['ga', 'gsc', 'gmb', 'gads'];
    
      // Use the 'every' method to check if a specific condition is true for all elements in the 'accessKeys' array.
      // In this case, it checks if the user has a property named with the format `${key}Checkedrevenue` set to a truthy value.
      // This implies that the user has the necessary access checked for the revenue report.
      return accessKeys.every((key) => user[`${key}Checkedrevenue`]);
    };
    
    const areAllAccessCheckedads = () => {
      // List of access keys that need to be checked for the ads report
      const accessKeys = ['ga', 'gsc', 'gmb', 'gads'];
    
      return accessKeys.every((key) => user[`${key}Checkedads`]);
    };
    
    const areAllAccessCheckedtraffic = () => {
      // List of access keys that need to be checked for the traffic report
      const accessKeys = ['ga', 'gsc', 'gmb', 'gads'];
    
      return accessKeys.every((key) => user[`${key}Checkedtraffic`]);
    };

      
    return (
        <>
            <div className="container">
                <h1 className="heading">Edit User</h1>
                <p id="success">User Updated Successfully!</p>
                <div className="row edit-user-row">
                <form onSubmit={e => updateFrom(e)}>

<div className="col-lg-12">
<div className="row">
<div className="col-lg-6 col-md-12 register-form-col"> 
<label >Name</label>
<input type="text"  name='user_name' className="form-control" value={name} onChange={e => handleChange(e)}/>
</div>


<div className="col-lg-6 col-md-12 register-form-col"> 
<label>Email</label>
<input type="email"  name='email' required className="form-control" value={email} onChange={e => handleChange(e)}/>
</div>
</div>

<div className="row">
<div className="col-lg-6 col-md-12 register-form-col"> 
<label>Website Url</label>
<input type="url"  name='url' required className="form-control" value={url} onChange={e => handleChange(e)}/>
</div>
<div className="col-lg-6 col-md-12 register-form-col"> 
<label>Slug</label>
<input type="text"  name='slug' required className="form-control" value={slug} onChange={e => handleChange(e)}/>
</div>
</div>

<br />

<div className="col-lg-6 col-md-12 register-form-col">

<div className="row access-row">
  <p className="select-reports">Select reports</p>
  <div className="col-lg-4 col-sm-12 access-required">
    <label>Revenue Report</label>
    <input
      type="checkbox"
      name="revenue"
      checked={selectedReports.includes("revenue")}
      onChange={() => handleReportCheckboxChange("revenue")}
    />
  </div>

  <div className="col-lg-4 col-sm-12 access-required">
    <label>ADS Report</label>
    <input
      type="checkbox"
      name="ads"
      checked={selectedReports.includes("ads")}
      onChange={() => handleReportCheckboxChange("ads")}
    />
  </div>

  <div className="col-lg-4 col-sm-12 access-required">
    <label>Traffic Report</label>
    <input
      type="checkbox"
      name="traffic"
      checked={selectedReports.includes("traffic")}
      onChange={() => handleReportCheckboxChange("traffic")}
    />
  </div>
</div>

</div>
<div className="row reports-row">
{selectedReports.includes("revenue") && (
     <div  className="col-lg-5 col-md-12 col-sm-12 add-new-report-card">
     <h2 className="report-heading revenue">Revenue Report</h2>
    <p className="reminder revenue">Reminder Mail Sent</p>
           {selectedReports.every(areAllAccessCheckedrevenue) && (
                <div className="col-lg-11 col-md-12 report-form-col">
                <label>Iframe Link</label>
             <input type="url"  className="form-control" name="iframelinkrevenue" value={iframelinkrevenue} onChange={e => handleChange(e)}/>
             </div>
             )}
   <div className="col-lg-11 col-md-12 report-form-col">
           <label>Access Granted</label>
           
           <div className="row access-row">
                   <div className="col-lg-3 col-sm-12 access-required checkbox revenue">
                     <label>GA</label>
                     <input
                       type="checkbox"
                       name="ga"
                       checked={gaCheckedrevenue}
                       onChange={handleGaChangerevenue}
                     />
                   </div>
                
                
                   <div className="col-lg-3 col-sm-12 access-required checkbox revenue">
                     <label>GSC</label>
                     <input
                       type="checkbox"
                       name="gsc"
                       checked={gscCheckedrevenue}
                       onChange={handleGscChangerevenue}
                     />
                   </div>
           
          
                   <div className="col-lg-3 col-sm-12 access-required checkbox revenue">
                     <label>GMB</label>
                     <input
                       type="checkbox"
                       name="gmb"
                       checked={gmbCheckedrevenue}
                       onChange={handleGmbChangerevenue}
                     />
                   </div>
              
                   <div className="col-lg-3 col-sm-12 access-required checkbox revenue">
                     <label>GADS</label>
                     <input
                       type="checkbox"
                       name="gads"
                       checked={gadsCheckedrevenue}
                       onChange={handleGadsChangerevenue}
                     />
                   </div>
               </div>
           <div className="row send-reminder-row">
           {!areAllAccessCheckedrevenue('revenue') && (
    <button type="button" className="reminder-button" onClick={event => sendReminder(event, 'revenue')}>
      Send Reminder
    </button>
  )}
  {selectedReports.every(areAllAccessCheckedrevenue) && (

  <button type="button" className="reminder-button">
   Publish
 </button>
   )}

           </div>
   </div>
                            </div>
  )}
{selectedReports.includes("ads") &&  (
 <div  className="col-lg-5 col-md-12 col-sm-12 add-new-report-card">
     <h2 className="report-heading ads">ADS Report</h2>
     <p className="reminder ads">Reminder Mail Sent</p>

     {selectedReports.every(areAllAccessCheckedads) && (
        <div className="col-lg-11 col-md-12 report-form-col">
           <label>Iframe Link</label>
             <input type="url"  className="form-control"  name="iframelinkads" value={iframelinkads} onChange={e => handleChange(e)}/>
   </div>
   )}
   <div className="col-lg-11 col-md-12 report-form-col">
           <label>Access Granted</label>
           <div className="row access-row">
                   
                   <div className="col-lg-3 col-sm-12 access-required checkbox ads">
                     <label>GA</label>
                     <input
                       type="checkbox"
                       name="ga"
                       checked={gaCheckedads}
                       onChange={handleGaChangeads}
                     />
                   </div>
                
                
                   <div className="col-lg-3 col-sm-12 access-required checkbox ads">
                     <label>GSC</label>
                     <input
                       type="checkbox"
                       name="gsc"
                       checked={gscCheckedads}
                       onChange={handleGscChangeads}
                     />
                   </div>
           
          
                   <div className="col-lg-3 col-sm-12 access-required checkbox ads">
                     <label>GMB</label>
                     <input
                       type="checkbox"
                       name="gmb"
                       checked={gmbCheckedads}
                       onChange={handleGmbChangeads}
                     />
                   </div>
              
                   <div className="col-lg-3 col-sm-12 access-required checkbox ads">
                     <label>GADS</label>
                     <input
                       type="checkbox"
                       name="gads"
                       checked={gadsCheckedads}
                       onChange={handleGadsChangeads}
                     />
                   </div>
               </div>
               <div className="row send-reminder-row">
               {!areAllAccessCheckedads('ads') && (
           <button type="button" className="reminder-button" onClick={event => sendReminder(event, 'ads')}>
                  Send Reminder
               </button>
                 )}
                  {selectedReports.every(areAllAccessCheckedads) && (
               <button type="button" className="reminder-button">
                  Publish
               </button>
                  )}
           </div>
   </div>
</div>
 )}
{selectedReports.includes("traffic") &&(
<div  className="col-lg-5 col-md-12 col-sm-12 add-new-report-card">
     <h2 className="report-heading traffic">Traffic Report</h2>
     <p className="reminder traffic">Reminder Mail Sent</p>

     {selectedReports.every(areAllAccessCheckedtraffic) && (
        <div className="col-lg-11 col-md-12 report-form-col">
           <label>Iframe Link</label>
             <input type="url"  className="form-control" name="iframelinktraffic" value={iframelinktraffic} onChange={e => handleChange(e)} />
   </div>
    )}
   <div className="col-lg-11 col-md-12 report-form-col">
           <label>Access Granted</label>
           <div className="row access-row">
                   
                   <div className="col-lg-3 col-sm-12 access-required checkbox traffic">
                     <label>GA</label>
                     <input
                       type="checkbox"
                       name="ga"
                       checked={gaCheckedtraffic}
                       onChange={handleGaChangetraffic}
                     />
                   </div>
                
                
                   <div className="col-lg-3 col-sm-12 access-required checkbox traffic">
                     <label>GSC</label>
                     <input
                       type="checkbox"
                       name="gsc"
                       checked={gscCheckedtraffic}
                       onChange={handleGscChangetraffic}
                     />
                   </div>
           
          
                   <div className="col-lg-3 col-sm-12 access-required checkbox traffic">
                     <label>GMB</label>
                     <input
                       type="checkbox"
                       name="gmb"
                       checked={gmbCheckedtraffic}
                       onChange={handleGmbChangetraffic}
                     />
                   </div>
              
                   <div className="col-lg-3 col-sm-12 access-required checkbox traffic">
                     <label>GADS</label>
                     <input
                       type="checkbox"
                       name="gads"
                       checked={gadsCheckedtraffic}
                       onChange={handleGadsChangetraffic}
                     />
                   </div>
               </div>
   </div>
   <div className="row send-reminder-row">
               {!areAllAccessCheckedtraffic('traffic') && (
           <button type="button" className="reminder-button" onClick={event => sendReminder(event, 'traffic')}>
                  Send Reminder
               </button>
                 )}
                  {selectedReports.every(areAllAccessCheckedtraffic) && (
               <button type="button" className="reminder-button">
                  Publish
               </button>
                  )}
           </div>
</div>
)}
</div>

{/* <button type="button" className="add-report" onClick={handleAddReportClick} id="add-report-buuton">
  {showAccessRow} 
  Add Report
</button> */}
    
<div className="col-lg-6 col-md-12 text-left register-button">
<div className="row edit-user-submit">
 <div className="col-lg-4 col-md-12">
 <input type="submit" name = 'submit' value='Update User' className="btn btn-success"/>
 </div>
 <div className="col-lg-4 col-md-12">
 <Link to='/home'>
  <button className="cancel">
    Cancel
   </button>
  </Link>
 </div>
</div>
 
</div>

</div>
</form>
                </div>
            </div>
        </>
    );
};
export default Edituser;





