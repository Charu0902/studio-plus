import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate,useParams } from "react-router-dom";
// import {Helmet} from "react-helmet";

const Dcompo = () =>{
    let history = useNavigate();
    const {slug} = useParams();
    const [user, setUser] = useState({
        slug:"",
        iframe_ga: "",
        website: ""
        
    });
    useEffect(() =>{
        
        loadUsers();
       
    },[])
    const {iframe_ga,website} = user

    const loadUsers = async ()=>{
        console.log('AA'+slug);
        const result = await axios.get('https://react.opositive.io/show-client-report.php?slug='+slug)
     
        setUser(result.data);
        var load = document.getElementById('loadingMessage');
        load.style.display = 'none';
    }
   
    return(
        <>
      <div id="loadingMessage">
      <img src="./Assets/voiceloader.gif" className="img-fluid"/>

      </div>
      <section>
      {/* <h2 className="heading">View report</h2> */}
       {/* <p>{website}</p> */}
       <div className="container">
       <div className="row">
          <div className="col-md-4">
            <h2>Report 1</h2>
          <iframe  src={iframe_ga} height='400' allowfullscreen className="user-iframe" id="foo"></iframe>

          </div>
          <div className="col-md-4">
            <h2>Report 2</h2>
          <iframe  src={iframe_ga} height='400' allowfullscreen className="user-iframe" id="foo"></iframe>

          </div>
          <div className="col-md-4">
            <h2>Report 3</h2>
          <iframe  src={iframe_ga} height='400' allowfullscreen className="user-iframe" id="foo"></iframe>

          </div>
       </div>
       </div>
      </section>
        </>
    )
}

export default Dcompo;