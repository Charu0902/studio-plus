import React from "react";

const Client = () =>{
    return(
<>
<h1>This is client page</h1>
</>
    )
}

export default Client;