import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

const Edituser = () => {
        // Use the useNavigate hook from react-router-dom to get the navigation function

    let history = useNavigate();

        // Use the useParams hook from react-router-dom to get the 'id' parameter from the URL

    const { id } = useParams();

        // Set the initial state for the user data using the useState hook

    const [user, setUser] = useState({
        name: "",
        email: "",
        url: "",
        password: "",
        slug: "",
        iframe: "",
        id: "",
        reportname:"",
        reportiframelink:"",
        reportimagelink:""
    });

    useEffect(() => {
        loadUsers();
    }, []);

        // Destructure the user state object for easier access to its properties

    const { name, email, url, password, slug, iframe,reportname, reportiframelink,reportimagelink} = user;

        // Handle input change for text fields (name, email, url, password, slug, and iframe)

    const handleChange = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value });
    };
        // Handle checkbox change for GA (Google Analytics) access
    // Handle form submission to update the user data
    const [reports, setReports] = useState([]);
    const updateFrom = async (e) => {
      e.preventDefault();
      console.log(user);

      // Convert checkbox values (gaChecked, gscChecked, gmbChecked, gadsChecked) to '1' or '0'
      const userData = {
          ...user,
          reports: [...reports], // Save the reports array in the userData object
      };
      console.log(userData);
  };
        // Load the user data from the backend API 
    const loadUsers = async () => {
        console.log('AA' + id);
        try {
                // Send a GET request to the backend API to get the user data based on the 'id'
            const result = await axios.get('https://react.opositive.io/edit-user.php?id=' + id);
             // Extract the user data from the API response
            const userFromServer = result.data;
               // Set the user state with the fetched user data and convert checkbox values to booleans

            setUser({
                ...userFromServer,
             
            });
        } catch (error) {
            console.error("Error fetching user data:", error);
        }
    };
    const [showForm, setShowForm] = useState(false);
    const handleAccessChange = (index, value) => {
      const updatedReports = [...reports];
      updatedReports[index]["access"] = value;
      setReports(updatedReports);
  };
    const handleAddReportClick = () => {
      // Create a new report object with default values or empty strings
      const newReport = {
          reportname: "",
          reportiframelink: "",
          reportimagelink: "",
          access: "Yes",
      };
      // Add the new report to the reports array
      setReports([...reports, newReport]);
  };
  // Handle "Cancel" button click to hide the form
  const handleReportChange = (index, field, value) => {
    const updatedReports = [...reports];
    updatedReports[index][field] = value;
    setReports(updatedReports);
};

    return (
        <>
            <div className="container">
                <h1 className="heading">Edit User</h1>
                <p id="success">User Updated Successfully!</p>
                <div className="row edit-user-row">
                <form onSubmit={e => updateFrom(e)}>

<div className="col-lg-12">
<div className="row">
<div className="col-lg-6 col-md-12 register-form-col"> 
<label >Name</label>
<input type="text"  name='name' className="form-control" value={name} onChange={e => handleChange(e)}/>
</div>


<div className="col-lg-6 col-md-12 register-form-col"> 
<label>Email</label>
<input type="email"  name='email' required className="form-control" value={email} onChange={e => handleChange(e)}/>
</div>
</div>

<div className="row">
<div className="col-lg-6 col-md-12 register-form-col"> 
<label>Website Url</label>
<input type="url"  name='url' required className="form-control" value={url} onChange={e => handleChange(e)}/>
</div>
<div className="col-lg-6 col-md-12 register-form-col"> 
<label>Iframe</label>
<textarea  name='iframe' required className="form-control" value={iframe} onChange={e => handleChange(e)}/>
</div>
</div>

<div className="row">
<div className="col-lg-6 col-md-12 register-form-col"> 
<label>Slug</label>
<input type="text"  name='slug' required className="form-control" value={slug} onChange={e => handleChange(e)}/>
</div>

<div className="col-lg-6 col-md-12 register-form-col"> 
<label>Password</label>
<input type="password"  name='password' required className="form-control"  autoComplete="on" value={password} onChange={e => handleChange(e)}/>
</div>
</div>
<div className="row reports-row">
{reports.map((report, index) => (
     <div key={index} className="col-lg-5 col-md-12 col-sm-12 add-new-report-card">
       <div className="col-lg-11 col-md-12 report-form-col">
          <label>Report Name</label>
              <input type="text" name={`reportname_${index}`}  value={report.reportname}  className="form-control"  onChange={e => handleReportChange(index, "reportname", e.target.value)} />
       </div>
        <div className="col-lg-11 col-md-12 report-form-col">
           <label>Iframe Link</label>
             <input type="url" name={`reportiframelink_${index}`} value={report.reportiframelink} className="form-control" onChange={e => handleReportChange(index, "reportiframelink", e.target.value)} />
                                </div>
   <div className="col-lg-11 col-md-12 report-form-col">
     <label>Image Link</label>
       <input type="url" name={`reportimagelink_${index}`} value={report.reportimagelink} className="form-control" onChange={e => handleReportChange(index, "reportimagelink", e.target.value)}  />
  </div>
  <div className="col-lg-11 col-md-12 report-form-col">
  <label>Access</label>
   <div className="row radio-access-row">
   <div className="col-lg-2 col-sm-12 radio-button-col">
  <label htmlFor={`access_${index}_yes`}>Yes</label>
     <input type="radio" name={`access_${index}`} className="radio-button-input" value="Yes"  checked={report.access === "Yes"} onChange={(e) => handleAccessChange(index, e.target.value)} />
                                                
  </div>
  <div className="col-lg-2 col-sm-12 radio-button-col">
  <label htmlFor={`access_${index}_no`}>No</label>
        <input type="radio" name={`access_${index}`} value="No" className="radio-button-input" checked={report.access === "No"} onChange={(e) => handleAccessChange(index, e.target.value)}/>
 </div>
    </div>
    </div>
                            </div>
                        ))}
</div>


<div className="row">
      <div className="col-lg-6 col-md-12 register-form-col">
          {/* Button to show the form */}
              <button type="button" onClick={handleAddReportClick} className="add-new-report">
                  Add new report
               </button>
      </div>
</div>
<div className="col-lg-6 col-md-12 text-left register-button">
<div className="row edit-user-submit">
 <div className="col-lg-4 col-md-12">
 <input type="submit" name = 'submit' value='Update User' className="btn btn-success"/>
 </div>
 <div className="col-lg-4 col-md-12">
 <Link to='/home'>
  <button className="cancel">
    Cancel
   </button>
  </Link>
 </div>
</div>
 
</div>

</div>
</form>
                </div>
            </div>
        </>
    );
};

export default Edituser;
